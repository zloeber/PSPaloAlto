---
external help file: PSPaloAlto-help.xml
online version: 
schema: 2.0.0
---

# Get-PAConnectionList
## SYNOPSIS
Returns list of connected Palo Altos.

## SYNTAX

```
Get-PAConnectionList
```

## DESCRIPTION
Returns list of connected Palo Altos.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Get-PAConnectionList
```

Description
      -----------
      Shows all the stored api connection objects.

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS

