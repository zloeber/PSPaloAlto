---
external help file: PSPaloAlto-help.xml
online version: 
schema: 2.0.0
---

# Get-PALastURL
## SYNOPSIS
Returns last URL used for an operation.

## SYNTAX

```
Get-PALastURL
```

## DESCRIPTION
Returns last URL used for an operation.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Get-PALastURL
```

Description
      -----------
      Shows last response from an operation.

## PARAMETERS

## INPUTS

## OUTPUTS

### XML.XMLDocument

## NOTES

## RELATED LINKS

