---
external help file: PSPaloAlto-help.xml
online version: 
schema: 2.0.0
---

# Get-PALastResponse
## SYNOPSIS
Returns last xml response returned from an operation.

## SYNTAX

```
Get-PALastResponse
```

## DESCRIPTION
Returns last xml response returned from an operation.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Get-PALastResponse
```

Description
      -----------
      Shows last response from an operation.

## PARAMETERS

## INPUTS

## OUTPUTS

### XML.XMLDocument

## NOTES

## RELATED LINKS

