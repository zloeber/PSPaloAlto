---
external help file: PSPaloAlto-help.xml
online version: 
schema: 2.0.0
---

# Test-PaConnection
## SYNOPSIS
Validates if the PA connection variable is set

## SYNTAX

```
Test-PaConnection
```

## DESCRIPTION
Validates if the PA connection variable is set

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Test-PaConnection
```

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS

